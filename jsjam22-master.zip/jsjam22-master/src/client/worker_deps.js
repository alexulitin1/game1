/* globals deps */
require('../glov/client/require.js');

deps.assert = require('assert');
