export type Box = {
  x: number;
  y: number;
  w: number;
  h: number;
};

export type Point2D = {
  x: number;
  y: number;
};
