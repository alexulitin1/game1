// Portions Copyright 2019 Jimb Esser (https://github.com/Jimbly/)
// Released under MIT License: https://opensource.org/licenses/MIT

export let Buffer = {};
Buffer.isBuffer = function (b) {
  return false;
};
