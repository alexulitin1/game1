export interface ExternalUserInfo {
  external_id: string; // '' if unspecified
  name?: string;
  profile_picture_url?: string;
  email?: string;
}
