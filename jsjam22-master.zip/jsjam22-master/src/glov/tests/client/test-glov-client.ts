/* eslint import/order:off */
import 'glov/client/test'; // Must be first

import assert from 'assert';
import 'glov/client/textures';

assert(true);
