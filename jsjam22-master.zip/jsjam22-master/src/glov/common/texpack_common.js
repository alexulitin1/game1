// bitmask
exports.FORMAT_PACK = 1<<0;
exports.FORMAT_PNG = 1<<1;
exports.TEXPACK_MAGIC = 0x8F49A352;
